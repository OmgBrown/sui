import React from 'react'
import { Menu, Icon, Container } from 'semantic-ui-react'

const Footer = () => (
    // <footer style={{textAlign: 'center'}}>
    //     2018 Leg Bill Builder
    // </footer>
    <Menu secondary fixed='bottom' inverted color='blue' size='tiny' style={{justifyContent: 'center'}}>
        <Menu.Item>
            <Icon name='copyright' />
            2018 Leg Bill Builder
        </Menu.Item>
    </Menu>

)


export default Footer;