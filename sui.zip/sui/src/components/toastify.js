import React, { Component } from 'react';
import { ToastContainer, toast } from 'react-toastify';

class toastify extends Component {
  notify = () => toast("Wow so easy !");

  render(){
    return (
      <div>
      <button onClick={this.notify}>Notify !</button>
        <ToastContainer autoClose={1500}/>
      </div>
    );
  }
}

export default toastify; 