import React, {Component} from 'react'
import { Input, Menu } from 'semantic-ui-react'

class Navmain extends Component {
    state = {activeItem: 'bills'}
    
    render () {
        const {activeItem} = this.state

        let handleItemClick = (e, {name}) => this.setState({activeItem: name})

        return (
            <Menu fixed='top' color='blue' inverted>
                <Menu.Item header>
                    Leg Bill Builder
                </Menu.Item>
                <Menu.Item name='Bills' active={activeItem === 'bills'} onClick={this.handleItemClick} />
                
            </Menu>
        )
    }
}


export default Navmain;